# Tomcat

[![Deploy to Azure](http://azuredeploy.net/deploybutton.png)](https://azuredeploy.net/)

Develop your Java website using Apache Tomcat. Apache Tomcat is an open source software implementation of the Java Servlet and JavaServer Pages technologies.Unlike the version available via web site configuration, this install is a completely customizable installation.
